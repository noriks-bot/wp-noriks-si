jQuery(function($) {
    const builder = $('#bundle-builder-qty');
    const qtyInput = $('form.cart input[name=quantity]');
    const colorInputs = builder.find('input[type=number]');
    const remainingDisplay = builder.find('.remaining');
    const maxPerUnit = 1;

    function getBundleQtyLimit() {
        let qty = parseInt(qtyInput.val()) || 1;
        return qty * maxPerUnit;
    }

    function totalItems() {
        let total = 0;
        colorInputs.each(function() {
            total += parseInt($(this).val()) || 0;
        });
        return total;
    }

    function updateDisplay() {
        const total = totalItems();
        const allowed = getBundleQtyLimit();
        remainingDisplay.text(`Odabrano ${total} of ${allowed} komada`);
    }

    function enforceTotalLimit() {
        let allowed = getBundleQtyLimit();
        let total = totalItems();

        if (total <= allowed) return;

        // Reduce overage starting from highest qty
        const sorted = colorInputs.toArray().sort((a, b) => {
            return parseInt($(b).val()) - parseInt($(a).val());
        });

        for (let i = 0; i < sorted.length && total > allowed; i++) {
            const $input = $(sorted[i]);
            let current = parseInt($input.val()) || 0;
            if (current > 0) {
                let reduction = Math.min(current, total - allowed);
                $input.val(current - reduction);
                total -= reduction;
            }
        }
    }

    builder.on('click', '.plus', function() {
        const input = $(this).siblings('input');
        input.val((parseInt(input.val()) || 0) + 1).trigger('change');
    });

    builder.on('click', '.minus', function() {
        const input = $(this).siblings('input');
        const val = parseInt(input.val()) || 0;
        if (val > 0) input.val(val - 1).trigger('change');
    });

    builder.on('change', 'input[type=number]', function() {
        enforceTotalLimit();
        updateDisplay();
    });

    qtyInput.on('change keyup', function() {
        enforceTotalLimit();
        updateDisplay();
    });

    // 🔁 Auto-click the first custom qty button on load
    const customQtyButtons = $('.custom-qty-buttons .qty-btn');
    if (customQtyButtons.length > 0) {
        customQtyButtons.removeClass('active');
        customQtyButtons.first().addClass('active').trigger('click');
    }

    updateDisplay();
});
