<?php
/*
Plugin Name: Orto Bundle Selector
Description: Custom bundle radio buttons for product 2598 (multiple pairs, color & size for each).
Version: 2.4
Author: Ante
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// === CONFIG ===

// ID of the product that should show the bundle UI
define( 'BUNDLE_PRODUCT_ID', 2598 ); // Orto bundle product

/**
 * Central config for offers (so front-end & pricing share same data).
 *
 * @return array
 */
function gck_get_bundle_offers() : array {
    return array(
        1 => array(
            'title'  => '1 majica',
            'per'    => 19.99,
            'total'  => 19.99,
            'saving' => 'Skupni prihranek €10.76',
        ),
        2 => array(
            'title'  => '2 majici',
            'per'    => 18.99,
            'total'  => 37.98,
            'saving' => 'Skupni prihranek €24.60',
        ),
        3 => array(
            'title'  => '3 majice',
            'per'    => 17.99,
            'total'  => 53.97,
            'saving' => 'Skupni prihranek €46.13',
        ),
        5 => array(
            'title'  => '6 majic',
            'per'    => 16.99,
            'total'  => 101.94,
            'saving' => 'Skupni prihranek €92.25',
        ),
    );
}

/**
 * Renders the bundle selector INSIDE the add-to-cart form.
 */
add_action( 'woocommerce_before_add_to_cart_button', 'gck_render_bundle_selector', 5 );
function gck_render_bundle_selector() {
    global $product;

    // Only on the chosen product page
    if ( ! is_product() || ! $product || (int) $product->get_id() !== (int) BUNDLE_PRODUCT_ID ) {
        return;
    }

    // Get custom (non-taxonomy) attribute values from this product
    $attributes = $product->get_attributes();

    // Size options (attribute name "Size" -> slug "size")
    $size_values = [];
    if ( isset( $attributes['size'] ) && ! $attributes['size']->is_taxonomy() ) {
        $size_values = $attributes['size']->get_options(); // e.g. [ 'S', 'M', ... ]
    }

    // Color options (attribute name "Color" -> slug "color")
    $color_values = [];
    if ( isset( $attributes['color'] ) && ! $attributes['color']->is_taxonomy() ) {
        $color_values = $attributes['color']->get_options(); // e.g. [ 'Black', 'Blue', ... ]
    }

    $offers = gck_get_bundle_offers();
    ?>
    <style>
        /* Hide default quantity for this product */
        body.single-product.postid-<?php echo (int) BUNDLE_PRODUCT_ID; ?> .quantity {
            display: none;
        }

        .bundle-box {
            margin: 25px 0;
        }
        .bundle-option {
            display: block;
            border: 2px solid #f0b18a;
            border-radius: 16px;
            padding: 15px;
            margin-bottom: 12px;
            cursor: pointer;
            position: relative;
        }
        .bundle-option input[type="radio"] {
            margin-right: 10px;
        }
        .bundle-option-title {
            font-weight: 600;
        }
        .bundle-option-sub {
            display: block;
            font-size: 13px;
            opacity: 0.8;
        }
        .bundle-option.active {
            border-color: #ff6d2e;
            background: #fff7f2;
        }
        .bundle-pairs {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px dashed #f0b18a;
        }
        .bundle-pair-row {
            margin-bottom: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }
        .bundle-pair-row span.pair-label {
            min-width: 60px;
            font-size: 13px;
            font-weight: 600;
        }
        .bundle-pair-row select {
            padding: 6px 8px;
        }
        .bundle-total-line {
            margin-top: 10px;
            text-align: right;
            font-weight: 600;
        }
        .bundle-total-line small {
            display: block;
            font-weight: normal;
            opacity: 0.7;
        }
        .hidden { display: none; }
        
        /* === SWATCHES === */
.color-swatches {
    display: flex;
    gap: 8px;
    align-items: center;
}

.color-swatches .swatch {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    border: 2px solid #ddd;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: all .15s;
}

.color-swatches .swatch.active {
    border-color: #ff6d2e;
    transform: scale(1.08);
}

.swatch-circle {
    width: 22px;
    height: 22px;
    border-radius: 50%;
}

/* Automatic color styles based on slug */
.color-black { background: #000; }
.color-blue { background: #3A6BF0; }
.color-green { background: #34A853; }
.color-gray { background: #999; }
.color-white { background: #fff; border: 1px solid #ccc; }

    </style>

    <div id="bundle-selector" class="bundle-box">

        <?php
        $first = true;
        foreach ( $offers as $pairs => $data ) : ?>
            <label class="bundle-option<?php echo $first ? ' active' : ''; ?>">
                <input type="radio"
                       name="bundle_option"
                       value="<?php echo esc_attr( $pairs ); ?>"
                       data-total="<?php echo esc_attr( $data['total'] ); ?>"
                       <?php checked( $first ); ?>>

                <span class="bundle-option-title">
                    <?php echo esc_html( $data['title'] ); ?> — €<?php echo number_format( $data['per'], 2 ); ?> / par
                </span>
                <span class="bundle-option-sub">
                    <?php echo esc_html( $data['saving'] ); ?>
                </span>

                <div class="bundle-total-line">
                    Skupni znesek: <span class="line-total">€<?php echo number_format( $data['total'], 2 ); ?></span>
                </div>

                <div class="bundle-pairs <?php echo $pairs === 1 ? '' : 'hidden'; ?>" data-pairs="<?php echo esc_attr( $pairs ); ?>">
                    <?php for ( $i = 1; $i <= $pairs; $i++ ) : ?>
                        <div class="bundle-pair-row">
                            <span class="pair-label"><?php echo $i; ?>. par</span>

                            <!-- Color select (custom attribute "Color") -->
                          <div class="color-swatches"
                                 data-name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][attribute_color]">
                            
                                <?php foreach ( $color_values as $val ) :
                                    $slug = sanitize_title( $val ); ?>
                                    <div class="swatch" data-value="<?php echo esc_attr( $val ); ?>" title="<?php echo esc_attr( $val ); ?>">
                                        <span class="swatch-circle color-<?php echo esc_attr( $slug ); ?>"></span>
                                    </div>
                                <?php endforeach; ?>
                            
                                <!-- Hidden field WooCommerce actually uses -->
                                <input type="hidden" class="swatch-input"
                                       name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][attribute_color]"
                                       value="">
                            </div>

                            <!-- Size select (custom attribute "Size") -->
                            <select name="pairs[<?php echo $pairs; ?>][<?php echo $i; ?>][attribute_size]">
                                <option value=""><?php esc_html_e( 'Size', 'gift-card-kompetentnost' ); ?></option>
                                <?php foreach ( $size_values as $val ) : ?>
                                    <option value="<?php echo esc_attr( $val ); ?>">
                                        <?php echo esc_html( $val ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endfor; ?>
                    <small><?php esc_html_e( 'Izbirate lahko med različnimi barvami in velikostmi za vsak par.', 'gift-card-kompetentnost' ); ?></small>
                </div>
            </label>
        <?php
        $first = false;
        endforeach;
        ?>

        <!-- quantity: bundle is ONE unit in cart -->
        <input type="hidden" id="bundle_quantity" name="quantity" value="1">

    </div>
    <?php
}

/**
 * Front-end script: toggle cards, update price visually, validate selects.
 */
add_action( 'wp_footer', 'gck_bundle_js' );
function gck_bundle_js() {
    if ( ! is_product() ) return;

    global $post;
    if ( ! $post || (int) $post->ID !== (int) BUNDLE_PRODUCT_ID ) return;
    ?>
<script>
document.addEventListener('DOMContentLoaded', function () {

    const selector = document.getElementById('bundle-selector');
    if (!selector) return;

    const radios   = selector.querySelectorAll('input[name="bundle_option"]');
    const qtyField = document.getElementById('bundle_quantity');

    function updateBundleUI(selectedRadio) {
        const selectedPairs = parseInt(selectedRadio.value);

        // highlight selected card
        selector.querySelectorAll('.bundle-option').forEach(function (card) {
            card.classList.remove('active');
        });
        selectedRadio.closest('.bundle-option').classList.add('active');

        // show only corresponding pairs block
        selector.querySelectorAll('.bundle-pairs').forEach(function (wrap) {
            const p = parseInt(wrap.getAttribute('data-pairs'));
            wrap.classList.toggle('hidden', p !== selectedPairs);
        });

        // quantity: bundle is always one unit in cart
        if (qtyField) {
            qtyField.value = 1;
        }

        // update visible price in Woo price element (simple visual)
        const total = selectedRadio.dataset.total;
        const priceElem = document.querySelector('.summary .price .woocommerce-Price-amount');
        if (priceElem && total) {
            priceElem.innerHTML = total.replace('.', ',') + ' €';
        }
    }

    radios.forEach(function (radio) {
        radio.addEventListener('change', function () {
            updateBundleUI(this);
        });
        if (radio.checked) {
            updateBundleUI(radio);
        }
    });

    // basic client-side validation: ensure each selected pair has size & color
    const form = document.querySelector('form.cart');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        const selectedRadio = selector.querySelector('input[name="bundle_option"]:checked');
        if (!selectedRadio) return;

        const pairs = parseInt(selectedRadio.value);
        const wrap  = selector.querySelector('.bundle-pairs[data-pairs="' + pairs + '"]');
        if (!wrap) return;

        let valid = true;
        wrap.querySelectorAll('.bundle-pair-row').forEach(function (row) {
            const selects = row.querySelectorAll('select');
            selects.forEach(function (sel) {
                if (!sel.value) {
                    valid = false;
                    sel.classList.add('woocommerce-invalid');
                } else {
                    sel.classList.remove('woocommerce-invalid');
                }
            });
        });

        if (!valid) {
            e.preventDefault();
            alert('Prosimo, izberite barvo in velikost za vsak par.');
        }
    });

});


/** SWATCH LOGIC **/
document.querySelectorAll('.color-swatches').forEach(swWrap => {
    const hidden = swWrap.querySelector('.swatch-input');

    swWrap.querySelectorAll('.swatch').forEach(swatch => {
        swatch.addEventListener('click', () => {

            // Remove active from other swatches inside same pair
            swWrap.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));

            // Mark clicked one
            swatch.classList.add('active');

            // Update hidden input value
            hidden.value = swatch.dataset.value;

            // Remove Woo invalid state
            hidden.classList.remove('woocommerce-invalid');
        });
    });
});



</script>
    <?php
}

/* ============================================================
 * CART / ORDER LOGIC
 * ============================================================*/

/**
 * Helper: build nice lines "Color - Size" per pair.
 *
 * @param array $pairs_data
 * @return array
 */
function gck_build_pair_lines( array $pairs_data ) : array {
    $lines = [];

    foreach ( $pairs_data as $index => $attrs ) {
        if ( ! is_array( $attrs ) ) continue;

        $color = isset( $attrs['attribute_color'] ) ? trim( (string) $attrs['attribute_color'] ) : '';
        $size  = isset( $attrs['attribute_size'] )  ? trim( (string) $attrs['attribute_size'] )  : '';

        if ( $color === '' && $size === '' ) {
            continue;
        }

        $line = $color;
        if ( $size !== '' ) {
            $line = $line ? $line . ' - ' . $size : $size;
        }

        if ( $line !== '' ) {
            $lines[] = $line;
        }
    }

    return $lines;
}

/**
 * When item is added to cart, attach bundle data:
 *  - number of pairs
 *  - bundle total price (single unit)
 *  - pair lines for meta ("Black - L", ...)
 */
add_filter( 'woocommerce_add_cart_item_data', 'gck_add_cart_item_data', 10, 3 );
function gck_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {

    // Only our Orto product AND only when bundle fields exist
    $pairs_selected = isset( $_POST['bundle_option'] ) ? absint( $_POST['bundle_option'] ) : 0;

    if ( (int) $product_id !== (int) BUNDLE_PRODUCT_ID || ! $pairs_selected ) {
        return $cart_item_data;
    }

    $offers = gck_get_bundle_offers();
    if ( ! isset( $offers[ $pairs_selected ] ) ) {
        return $cart_item_data;
    }

    // Extract selected pair attributes from POST.
    $pairs_all  = isset( $_POST['pairs'] ) ? (array) $_POST['pairs'] : [];
    $pairs_data = isset( $pairs_all[ $pairs_selected ] ) ? (array) $pairs_all[ $pairs_selected ] : [];

    // Meta lines like "Black - L"
    $lines = gck_build_pair_lines( $pairs_data );

    // Pricing: bundle is ONE product, price = bundle total
    $total      = (float) $offers[ $pairs_selected ]['total']; // bundle total
    $unit_price = $total;

    // Attach pricing & meta to cart item
    $cart_item_data['_orto_bundle_pairs']      = $pairs_selected;
    $cart_item_data['_orto_bundle_total']      = $total;
    $cart_item_data['_orto_bundle_unit_price'] = $unit_price;
    $cart_item_data['_orto_pairs_json']        = wp_json_encode( $pairs_data );
    $cart_item_data['_orto_lines']             = $lines;

    // Prevent Woo from merging bundles with different selections
    $cart_item_data['orto_unique_key'] = md5( microtime( true ) . wp_rand() . serialize( $cart_item_data ) );

    return $cart_item_data;
}

/**
 * Central helper: actually apply our custom unit price to a cart item.
 *
 * @param array $cart_item
 * @return array
 */
function gck_apply_price_to_cart_item( $cart_item ) {
    if ( isset( $cart_item['_orto_bundle_unit_price'] ) && $cart_item['data'] instanceof WC_Product ) {
        $price = (float) $cart_item['_orto_bundle_unit_price'];
        if ( $price > 0 ) {
            $cart_item['data']->set_price( $price );
        }
    }
    return $cart_item;
}

/**
 * Apply price when item is first added to cart.
 */
add_filter( 'woocommerce_add_cart_item', 'gck_add_cart_item_apply_price', 20, 2 );
function gck_add_cart_item_apply_price( $cart_item, $cart_item_key ) {
    return gck_apply_price_to_cart_item( $cart_item );
}

/**
 * Apply price when cart is loaded from session (page reload, etc.).
 */
add_filter( 'woocommerce_get_cart_item_from_session', 'gck_session_cart_item_apply_price', 20, 2 );
function gck_session_cart_item_apply_price( $cart_item, $values ) {
    if ( isset( $values['_orto_bundle_unit_price'] ) ) {
        $cart_item['_orto_bundle_unit_price'] = $values['_orto_bundle_unit_price'];
    }
    if ( isset( $values['_orto_lines'] ) ) {
        $cart_item['_orto_lines'] = $values['_orto_lines'];
    }
    return gck_apply_price_to_cart_item( $cart_item );
}

/**
 * Extra safety: before totals are calculated, make sure price is correct.
 */
add_action( 'woocommerce_before_calculate_totals', 'gck_adjust_bundle_price', 9999 );
function gck_adjust_bundle_price( $cart ) {
    if ( ! $cart instanceof WC_Cart ) {
        return;
    }

    foreach ( $cart->get_cart() as $key => &$item ) {
        $item = gck_apply_price_to_cart_item( $item );
    }
}

/**
 * Show bundle contents in cart / checkout under the line item.
 */
add_filter( 'woocommerce_get_item_data', 'gck_display_item_data', 10, 2 );
function gck_display_item_data( $item_data, $cart_item ) {

    if ( empty( $cart_item['_orto_lines'] ) || ! is_array( $cart_item['_orto_lines'] ) ) {
        return $item_data;
    }

    $lines     = array_values( $cart_item['_orto_lines'] );
    $numbered  = [];
    foreach ( $lines as $i => $line ) {
        $numbered[] = ( $i + 1 ) . ': ' . $line;
    }

    $value = implode( '<br>', array_map( 'esc_html', $numbered ) );

    // name=false -> Woo prints only the value (no dt label)
    $item_data[] = array(
        'name'    => false,
        'display' => $value,
    );

    return $item_data;
}

/**
 * Save each pair as a numbered meta line in the order item:
 * meta key "1" => "Black - L", "2" => "White - M", ...
 */
add_action( 'woocommerce_checkout_create_order_line_item', 'gck_order_item_meta', 10, 4 );
function gck_order_item_meta( $item, $cart_item_key, $values, $order ) {

    if ( empty( $values['_orto_lines'] ) || ! is_array( $values['_orto_lines'] ) ) {
        return;
    }

    $lines = array_values( $values['_orto_lines'] );
    foreach ( $lines as $i => $line ) {
        $item->add_meta_data( (string) ( $i + 1 ), sanitize_text_field( $line ), true );
    }

    if ( ! empty( $values['_orto_bundle_pairs'] ) ) {
        $item->add_meta_data( '_bundle_pairs', (int) $values['_orto_bundle_pairs'], true );
    }
}
